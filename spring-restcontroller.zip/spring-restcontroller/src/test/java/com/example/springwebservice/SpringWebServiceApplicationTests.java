package com.example.springwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
